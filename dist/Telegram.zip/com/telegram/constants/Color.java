/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.telegram.constants;

/**
 *
 * @author Devashish
 */
public class Color {
    public static int WHITE = 1;
    public static int GREEN = 2;
    public static int BLACK = 3;
    public static int BLUE = 4;
}
